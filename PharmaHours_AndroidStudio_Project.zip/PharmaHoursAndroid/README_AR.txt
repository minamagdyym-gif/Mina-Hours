مشروع تطبيق ساعات الصيدلية - Android Studio

مهم:
- وقت الراحة لا يتم خصمه؛ المدة من الحضور إلى الانصراف تُحسب كاملة كساعات عمل.
- هذا مشروع Android Studio جاهز للبناء، وليس ملف APK مُجمّعًا.
- لإنشاء APK: افتح المجلد في Android Studio، انتظر مزامنة Gradle، ثم اختر:
  Build > Build Bundle(s) / APK(s) > Build APK(s)
- ستجد الناتج عادةً داخل:
  app/build/outputs/apk/debug/app-debug.apk

يتطلب Android Studio وAndroid SDK (API 35) واتصالًا بالإنترنت أول مرة لتنزيل أدوات Gradle.
البيانات تحفظ محليًا داخل التطبيق على الجهاز.
